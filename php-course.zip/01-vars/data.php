<?php

// 01-vars/data.php

// Задаваме стойност на променливи за име, възраст и email:
// Слагаме "точка-запетая" на всеки ред!
$name = "John Doe";
$age = 25;
$email = "john.doe@example.com";
