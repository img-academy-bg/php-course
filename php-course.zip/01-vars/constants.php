<?php

// 01-vars/constants.php

define("MY_CONSTANT_NAME", "some value");

echo MY_CONSTANT_NAME;


// Грешно:
//MY_CONSTANT_NAME = "some value";
//define("MY_CONSTANT_NAME", "other value");
//unset(MY_CONSTANT_NAME);