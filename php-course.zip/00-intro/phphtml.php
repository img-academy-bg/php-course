<!DOCTYPE html>
<html>
    <head>
        <title>PHP and HTML</title>
    </head>
    <body>
        <h1>
            <?php echo "This is PHP title"; ?>
        </h1>
        <?= "<h3>This is subtitle</h3>"; ?>
    </body>
</html>