<?php

// output.php

echo "This is text from output.php";
